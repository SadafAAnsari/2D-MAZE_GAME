#include <iostream>
#include <fstream>
#include <conio.h>      // kbhit(), getch()
#include <windows.h>    // Sleep(), SetConsoleCursorPosition()
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iomanip>
#include <string>

using namespace std;

// Adjusted grid size for fuller screen coverage
const int GRID_ROWS = 25;
const int GRID_COLS = 100;

const char PLAYER_CHAR      = 'O';
const char FLOOR_CHAR       = '=';
const char EMPTY_CHAR       = ' ';
const char OBSTACLE_CHAR    = '^';
const char COLLECTIBLE_CHAR = '*';
const char FINISH_CHAR      = 'F';

// Helper: console handle + reposition
static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
inline void resetCursor() {
    COORD coord = { 0, 0 };
    SetConsoleCursorPosition(hConsole, coord);
}

inline bool inBounds(int x, int y) {
    return x >= 0 && x < GRID_COLS && y >= 0 && y < GRID_ROWS;
}

class Entity {
public:
    int x, y;
    char symbol;
    Entity(int x, int y, char symbol) : x(x), y(y), symbol(symbol) {}
    virtual void update() {}
};

class Player : public Entity {
public:
    bool isJumping;
    int jumpCount;
    Player(int x, int y) : Entity(x, y, PLAYER_CHAR), isJumping(false), jumpCount(0) {}

    void jump() {
        if (!isJumping) {
            isJumping = true;
            jumpCount = 3;
        }
    }
    void updateJump() {
        if (isJumping) {
            if (jumpCount > 0) {
                y--; jumpCount--;
            } else if (y < GRID_ROWS - 2) {
                y++;
            } else {
                isJumping = false;
            }
        } else if (y < GRID_ROWS - 2) {
            y++;
        }
    }
};

class Obstacle : public Entity {
public:
    Obstacle(int x, int y) : Entity(x, y, OBSTACLE_CHAR) {}
};

class Collectible : public Entity {
public:
    Collectible(int x, int y) : Entity(x, y, COLLECTIBLE_CHAR) {}
};

class Maze {
public:
    char base[GRID_ROWS][GRID_COLS];
    char grid[GRID_ROWS][GRID_COLS];

    Maze() {
        buildBase();
        reset();
    }

    void buildBase() {
        for (int i = 0; i < GRID_ROWS; i++)
            for (int j = 0; j < GRID_COLS; j++)
                base[i][j] = EMPTY_CHAR;

        // Floor + finish
        for (int j = 0; j < GRID_COLS; j++)
            base[GRID_ROWS - 1][j] = FLOOR_CHAR;
        base[GRID_ROWS - 1][GRID_COLS - 1] = FINISH_CHAR;
    }

    // Copy static → working
    void reset() {
        for (int i = 0; i < GRID_ROWS; i++)
            for (int j = 0; j < GRID_COLS; j++)
                grid[i][j] = base[i][j];
    }

    void draw(int score, int moves, int level) {
        resetCursor();
        // draw grid
        for (int i = 0; i < GRID_ROWS; i++) {
            for (int j = 0; j < GRID_COLS; j++)
                cout << grid[i][j];
            cout << "\n";
        }
        // stats
        cout << "\nLevel: " << level
             << "    Score: " << score
             << "    Moves: " << moves << "\n";
        cout << "Controls: W = Jump, D = Forward, S = Backward\n";
    }
};

void displayMainMenu() {
    resetCursor();
    cout << string(GRID_COLS, '=') << "\n";
    cout << setw((GRID_COLS - 28) / 2) << "" << "*** Geometry Dash Console ***" << setw((GRID_COLS - 28) / 2) << "" << "\n";
    cout << string(GRID_COLS, '=') << "\n";
    cout << "1. Start Game\n";
    cout << "2. How to Play\n";
    cout << "3. Exit\n";
}

void displayHowToPlay() {
    resetCursor();
    cout << string(GRID_COLS, '=') << "\n";
    cout << setw((GRID_COLS - 17) / 2) << "" << "How to Play" << setw((GRID_COLS - 17) / 2) << "" << "\n";
    cout << string(GRID_COLS, '=') << "\n";
    cout << "W - Jump\n";
    cout << "D - Move Forward\n";
    cout << "S - Move Backward\n\n";
    cout << "Avoid spikes (" << OBSTACLE_CHAR << ").\n";
    cout << "Collect stars (" << COLLECTIBLE_CHAR << ") for +5 points.\n";
    cout << "Reach finish (F) to clear level.\n";
}

bool gameLoop(int level) {
    Maze maze;
    Player player(5, GRID_ROWS - 2);
    int score = 0, moves = 0, frame = 0;
    vector<Obstacle> obstacles;
    vector<Collectible> collectibles;

    // First draw to set cursor at bottom
    maze.draw(score, moves, level);

    while (true) {
        // static background
        maze.reset();

        // move + draw obstacles
        for (auto it = obstacles.begin(); it != obstacles.end(); ) {
            it->x -= 1 + (level / 2);
            if (!inBounds(it->x, it->y)) {
                it = obstacles.erase(it);
            } else {
                maze.grid[it->y][it->x] = it->symbol;
                ++it;
            }
        }
        // move + draw collectibles
        for (auto it = collectibles.begin(); it != collectibles.end(); ) {
            it->x -= 1 + (level / 3);
            if (!inBounds(it->x, it->y)) {
                it = collectibles.erase(it);
            } else {
                maze.grid[it->y][it->x] = it->symbol;
                ++it;
            }
        }

        // spawn
        if (frame % max(1, 20 - level) == 0)
            obstacles.emplace_back(GRID_COLS - 1, GRID_ROWS - 2);
        if (frame % max(1, 25 - level) == 0)
            collectibles.emplace_back(GRID_COLS - 1, GRID_ROWS - 3);

        // place player
        maze.grid[player.y][player.x] = player.symbol;

        // draw everything in place
        maze.draw(score, moves, level);

        // input
        if (kbhit()) {
            char c = getch();
            if (c=='w'||c=='W') { player.jump(); moves++; }
            if (c=='d'||c=='D' && player.x < GRID_COLS-1) { player.x++; moves++; }
            if (c=='s'||c=='S' && player.x > 0) { player.x--; moves++; }
        }

        player.updateJump();

        // win
        if (player.x >= GRID_COLS - 1) {
            maze.draw(score, moves, level);
            cout << "\nLevel " << level << " Complete!\n";
            Sleep(1500);
            return true;
        }

        // collision
        for (auto &obs : obstacles) {
            if (abs(obs.x - player.x) <= 1 && obs.y == player.y) {
                resetCursor();
                cout << "\nGame Over! You hit a spike.\n";
                Sleep(1500);
                return false;
            }
        }
        // collect
        for (auto it = collectibles.begin(); it != collectibles.end();) {
            if (abs(it->x - player.x) <= 1 && it->y == player.y) {
                score += 5;
                it = collectibles.erase(it);
            } else ++it;
        }

        frame++;
        Sleep(100);
    }
}

int main() {
    srand((unsigned)time(0));
    int choice = 0;

    // hide cursor for less distraction
    CONSOLE_CURSOR_INFO info;
    GetConsoleCursorInfo(hConsole, &info);
    info.bVisible = FALSE;
    SetConsoleCursorInfo(hConsole, &info);

    do {
        displayMainMenu();
        cout << "\nEnter choice: ";
        cin >> choice;

        if (choice == 1) {
            bool gameOver = false;
            for (int lvl = 1; lvl <= 4; ++lvl) {
                resetCursor();
                cout << "\nStarting Level " << lvl << "...\n";
                Sleep(1000);
                if (!gameLoop(lvl)) {
                    gameOver = true;
                    break;
                }
                resetCursor();
                cout << "\nLevel " << lvl << " Complete! Press any key...\n";
                getch();
            }
            resetCursor();
            if (!gameOver)
                cout << "\nCongratulations! You beat all levels!\n";
            cout << "Press any key to return to menu...\n";
            getch();

        } else if (choice == 2) {
            displayHowToPlay();
            cout << "\nPress any key...\n";
            getch();

        } else if (choice == 3) {
            resetCursor();
            cout << "\nGoodbye!\n";

        } else {
            resetCursor();
            cout << "\nInvalid. Try again.\n";
            Sleep(1000);
        }
    } while (choice != 3);

    return 0;
}
