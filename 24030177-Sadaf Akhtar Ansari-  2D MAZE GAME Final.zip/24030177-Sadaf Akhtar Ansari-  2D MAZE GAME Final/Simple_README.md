
# Geometry Dash Console Game

This is a simple console-based game written in C++.

## How to Run

1. Compile the code:
   ```
   g++ Jmpinggame.cpp -o GeometryDashGame
   ```

2. Run the game:
   ```
   ./GeometryDashGame
   ```

## Controls

- W - Jump
- D - Move Forward
- S - Move Backward

## Objective

Avoid spikes (^), collect stars (*), and reach the finish line (F) to complete the level.

## Author

Sadaf Akhtar Ansari
